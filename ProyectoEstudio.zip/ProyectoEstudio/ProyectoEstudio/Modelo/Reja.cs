﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEstudio.Modelo
{
    public class Reja
    {
        //Atributos
        double largo = 2.5;
        double altura = 0;
        Color color;

        public Reja()
        {
        }



        //Methods
        public Reja(double largo, double altura, string Color)
        {
            this.largo = largo;
            this.altura = altura;

            if (Color.Equals("")) {
                this.color = 0;
            }
            else
            {
                if (Color.Equals("Rojo"))
                {
                    this.color = Modelo.Color.Red;
                }
                else if (Color.Equals("Verde"))
                {
                    this.color= Modelo.Color.Green;
                }
                else if (Color.Equals("Azul"))
                {
                    this.color = Modelo.Color.Blue;
                }
            }
        }
    }

    public enum Color
    {
        NoColor = 0,
        Red = 1,
        Green = 2,
        Blue = 2
    }
}
