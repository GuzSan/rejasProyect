using ProyectoEstudio.Controlador;
using ProyectoEstudio.Modelo;
using System.Windows.Forms;

namespace ProyectoEstudio
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            Reja reja = new Reja();
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HistorialController historialController = new HistorialController();
            if (LstColor.SelectedItem.ToString().Equals("Sin pintura"))
            {
                picBox.Image = Properties.Resources.rejablanca;
                Largo.Text = txtLargo.Text;
                Altura.Text = lstAltura.SelectedItem.ToString()+"m";
                historialController.InsertarDato(LstColor.SelectedItem.ToString(), Convert.ToDouble(Altura.Text),Convert.ToDouble(Largo.Text),4*Convert.ToDouble(Altura.Text),DateTime.Today);
            
            }
            else if (LstColor.SelectedItem.ToString().Equals("blanca"))
            {
                picBox.Image = Properties.Resources.sincolor;
                Largo.Text = txtLargo.Text;
                Altura.Text = lstAltura.SelectedItem.ToString();
            }
            else if (LstColor.SelectedItem.ToString().Equals("negra"))
            {
                picBox.Image = Properties.Resources.negra;
                Largo.Text = txtLargo.Text;
                Altura.Text = lstAltura.SelectedItem.ToString();

            }
            else if (LstColor.SelectedItem.ToString().Equals("verde"))
            {
                picBox.Image = Properties.Resources.verde;
                Largo.Text = txtLargo.Text;
                Altura.Text = lstAltura.SelectedItem.ToString();

            }
            else
            {
                throw new Exception();
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void chkSI_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void picBox_Click(object sender, EventArgs e)
        {

        }

        private void LstColor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Largo_Click(object sender, EventArgs e)
        {

        }
    }
}
