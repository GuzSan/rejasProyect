﻿namespace ProyectoEstudio
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnComprar = new Button();
            lblLargo = new Label();
            txtLargo = new TextBox();
            label1 = new Label();
            LstColor = new ListBox();
            lblColor = new Label();
            label2 = new Label();
            chkSI = new CheckBox();
            chkNO = new CheckBox();
            lstAltura = new ListBox();
            picBox = new PictureBox();
            Largo = new Label();
            Altura = new Label();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)picBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnComprar
            // 
            btnComprar.Location = new Point(681, 329);
            btnComprar.Name = "btnComprar";
            btnComprar.Size = new Size(75, 23);
            btnComprar.TabIndex = 0;
            btnComprar.Text = "Comprar";
            btnComprar.UseVisualStyleBackColor = true;
            btnComprar.Click += button1_Click;
            // 
            // lblLargo
            // 
            lblLargo.AutoSize = true;
            lblLargo.Location = new Point(484, 47);
            lblLargo.Name = "lblLargo";
            lblLargo.Size = new Size(43, 15);
            lblLargo.TabIndex = 1;
            lblLargo.Text = "Largo: ";
            // 
            // txtLargo
            // 
            txtLargo.Location = new Point(546, 47);
            txtLargo.Name = "txtLargo";
            txtLargo.Size = new Size(100, 23);
            txtLargo.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(484, 85);
            label1.Name = "label1";
            label1.Size = new Size(42, 15);
            label1.TabIndex = 3;
            label1.Text = "Altura:";
            // 
            // LstColor
            // 
            LstColor.FormattingEnabled = true;
            LstColor.ItemHeight = 15;
            LstColor.Items.AddRange(new object[] { "Sin pintura", "blanca", "negra", "verde" });
            LstColor.Location = new Point(546, 178);
            LstColor.Name = "LstColor";
            LstColor.Size = new Size(100, 64);
            LstColor.TabIndex = 5;
            LstColor.SelectedIndexChanged += LstColor_SelectedIndexChanged;
            // 
            // lblColor
            // 
            lblColor.AutoSize = true;
            lblColor.Location = new Point(484, 187);
            lblColor.Name = "lblColor";
            lblColor.Size = new Size(39, 15);
            lblColor.TabIndex = 6;
            lblColor.Text = "Color:";
            lblColor.Click += label2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(448, 257);
            label2.Name = "label2";
            label2.Size = new Size(83, 15);
            label2.TabIndex = 8;
            label2.Text = "Confirmacion:";
            // 
            // chkSI
            // 
            chkSI.AutoSize = true;
            chkSI.Location = new Point(546, 266);
            chkSI.Name = "chkSI";
            chkSI.Size = new Size(35, 19);
            chkSI.TabIndex = 9;
            chkSI.Text = "Si";
            chkSI.UseVisualStyleBackColor = true;
            chkSI.CheckedChanged += chkSI_CheckedChanged;
            // 
            // chkNO
            // 
            chkNO.AutoSize = true;
            chkNO.Location = new Point(610, 266);
            chkNO.Name = "chkNO";
            chkNO.Size = new Size(42, 19);
            chkNO.TabIndex = 10;
            chkNO.Text = "No";
            chkNO.UseVisualStyleBackColor = true;
            // 
            // lstAltura
            // 
            lstAltura.FormattingEnabled = true;
            lstAltura.ItemHeight = 15;
            lstAltura.Items.AddRange(new object[] { "1.03m", "1.53m", "2.03m" });
            lstAltura.Location = new Point(546, 85);
            lstAltura.Name = "lstAltura";
            lstAltura.Size = new Size(100, 64);
            lstAltura.TabIndex = 11;
            lstAltura.SelectedIndexChanged += listBox2_SelectedIndexChanged;
            // 
            // picBox
            // 
            picBox.Image = Properties.Resources.sincolor;
            picBox.Location = new Point(12, 12);
            picBox.Name = "picBox";
            picBox.Size = new Size(363, 230);
            picBox.TabIndex = 12;
            picBox.TabStop = false;
            picBox.Click += picBox_Click;
            // 
            // Largo
            // 
            Largo.AutoSize = true;
            Largo.Location = new Point(215, 243);
            Largo.Name = "Largo";
            Largo.Size = new Size(37, 15);
            Largo.TabIndex = 13;
            Largo.Text = "Largo";
            Largo.Click += Largo_Click;
            // 
            // Altura
            // 
            Altura.AutoSize = true;
            Altura.Location = new Point(381, 125);
            Altura.Name = "Altura";
            Altura.Size = new Size(29, 15);
            Altura.TabIndex = 14;
            Altura.Text = "Alto";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(122, 288);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(240, 150);
            dataGridView1.TabIndex = 15;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Controls.Add(Altura);
            Controls.Add(Largo);
            Controls.Add(picBox);
            Controls.Add(lstAltura);
            Controls.Add(chkNO);
            Controls.Add(chkSI);
            Controls.Add(label2);
            Controls.Add(lblColor);
            Controls.Add(LstColor);
            Controls.Add(label1);
            Controls.Add(txtLargo);
            Controls.Add(lblLargo);
            Controls.Add(btnComprar);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)picBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnComprar;
        private Label lblLargo;
        private TextBox txtLargo;
        private Label label1;
        private ListBox LstColor;
        private Label lblColor;
        private Label label2;
        private CheckBox chkSI;
        private CheckBox chkNO;
        private ListBox lstAltura;
        private PictureBox picBox;
        private Label Largo;
        private Label Altura;
        private DataGridView dataGridView1;
    }
}
