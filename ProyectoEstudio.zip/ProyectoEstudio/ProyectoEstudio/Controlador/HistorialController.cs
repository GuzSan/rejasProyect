﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEstudio.Controlador
{
    public class HistorialController
    {
        string connectionString = "YourConnectionString"; //this is the connection string we need to connect to the database
        public HistorialController() { }
        public void InsertarDato(string color, double altura, double largo, int fijadores, DateTime fechaConfirmacion)
        {
            // Insert data
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                var newEntity = new  { Property = "New Data" };
                //connection.Execute("INSERT INTO YourTable (Property) VALUES (@Property)", newEntity);
            }
        }
    }
}
